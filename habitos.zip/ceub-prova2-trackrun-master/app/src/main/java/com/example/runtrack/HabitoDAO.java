package com.example.habitotrack.data;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface HabitoDao {

    @Insert
    void insert(Habito habito);

    @Delete
    void delete(Habito habito);

    @Query("SELECT * FROM habitos")
    List<Habito> getAll();

    @Query("SELECT * FROM habitos ORDER BY id DESC LIMIT 1")
    Habito getLast();

    @Query("SELECT * FROM habitos ORDER BY frequencia DESC LIMIT 1")
    Habito getTopByFrequency();
}
