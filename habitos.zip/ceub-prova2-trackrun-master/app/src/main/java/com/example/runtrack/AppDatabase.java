package com.example.habitotrack.data;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.example.runtrack.Habito;

@Database(entities = {Habito.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    public abstract com.example.habitotrack.data.HabitoDao habitoDao();
}
