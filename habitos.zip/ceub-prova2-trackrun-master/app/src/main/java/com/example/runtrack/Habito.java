package com.example.runtrack;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "habitos")
public class Habito {
    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "nome")
    private String nome;

    @ColumnInfo(name = "descricao")
    private String descricao;

    @ColumnInfo(name = "frequencia")
    private int frequencia;

    public Habito(String nome, String descricao, int frequencia) {
        this.nome = nome;
        this.descricao = descricao;
        this.frequencia = frequencia;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public int getFrequencia() { return frequencia; }
    public void setFrequencia(int frequencia) { this.frequencia = frequencia; }
}
