package com.example.habitotrack;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import com.example.habitotrack.data.AppDatabase;
import com.example.habitotrack.data.Habito;
import com.example.habitotrack.data.HabitoDAO;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private EditText nome;
    private EditText descricao;
    private EditText frequencia;
    private Button salvar, excluir;
    private TextView informacoes;
    private AppDatabase db;
    private HabitoDAO habitoDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        nome        = findViewById(R.id.editTextNome);
        descricao   = findViewById(R.id.editTextDescricao);
        frequencia  = findViewById(R.id.editTextFrequencia);
        salvar      = findViewById(R.id.buttonSalvar);
        excluir     = findViewById(R.id.buttonExcluir);
        informacoes = findViewById(R.id.textViewInformacoes);

        db = Room.databaseBuilder(
                getApplicationContext(),
                AppDatabase.class,
                "habitos.db"
        ).build();
        habitoDAO = db.habitoDAO();

        buscarHabitos();

        salvar.setOnClickListener(v -> salvarHabito());
        excluir.setOnClickListener(v -> excluirHabito());
    }

    private void salvarHabito() {
        String nomeStr  = nome.getText().toString().trim();
        String descStr  = descricao.getText().toString().trim();
        String freqStr  = frequencia.getText().toString().trim();

        if (nomeStr.isEmpty() || freqStr.isEmpty()) {
            Toast.makeText(this, "Preencha nome e frequência!", Toast.LENGTH_SHORT).show();
            return;
        }

        int freq;
        try {
            freq = Integer.parseInt(freqStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Frequência deve ser número inteiro!", Toast.LENGTH_SHORT).show();
            return;
        }

        Habito novoHabito = new Habito(nomeStr, descStr, freq);

        new Thread(() -> {
            habitoDAO.insereHabito(novoHabito);
            runOnUiThread(() -> {
                nome.setText("");
                descricao.setText("");
                frequencia.setText("");
                Toast.makeText(this, "Hábito salvo!", Toast.LENGTH_SHORT).show();
                buscarHabitos();
            });
        }).start();
    }

    private void excluirHabito() {
        new Thread(() -> {
            Habito ultimo = habitoDAO.buscaUltimoHabito();
            if (ultimo != null) {
                habitoDAO.deletaHabito(ultimo);
            }
            runOnUiThread(() -> {
                Toast.makeText(this,
                        (ultimo != null ? "Último hábito excluído!" : "Nenhum hábito para excluir."),
                        Toast.LENGTH_SHORT
                ).show();
                buscarHabitos();
            });
        }).start();
    }

    private void buscarHabitos() {
        new Thread(() -> {
            List<Habito> todos = habitoDAO.buscaTodosHabitos();
            int totalFreq = 0;
            for (Habito h : todos) totalFreq += h.getFrequencia();

            Habito ultimo = todos.isEmpty() ? null : habitoDAO.buscaUltimoHabito();
            Habito maior  = todos.isEmpty() ? null : habitoDAO.buscaMaiorHabito();

            runOnUiThread(() -> {
                if (todos.isEmpty()) {
                    informacoes.setText("Nenhum hábito cadastrado.");
                } else {
                    StringBuilder sb = new StringBuilder();
                    sb.append("Frequência total diária: ")
                            .append(totalFreq)
                            .append(" vezes\n\n");
                    if (ultimo != null) {
                        sb.append("Último hábito:\n • Nome: ")
                                .append(ultimo.getNome())
                                .append("\n • Descrição: ")
                                .append(ultimo.getDescricao())
                                .append("\n • Frequência: ")
                                .append(ultimo.getFrequencia())
                                .append(" vez(es)\n\n");
                    }
                    if (maior != null) {
                        sb.append("Hábito com maior frequência:\n • Nome: ")
                                .append(maior.getNome())
                                .append("\n • Frequência: ")
                                .append(maior.getFrequencia())
                                .append(" vez(es)");
                    }
                    informacoes.setText(sb.toString());
                }
            });
        }).start();
        Habito novoHabito = new Habito(nomeStr, descStr, freq);

    }
}

